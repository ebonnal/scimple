Scimple Lib
Plot your data scimply
github.com/EnzoBnl/Scimple

Enzo Bonnal
enzobonnal@gmail.com

TEST:
	Test package by running: 
	pip install scimple
	or locally within cloned repository: pip install .
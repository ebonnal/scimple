# Scimple Lib

##### Kafka & Spark & Stat & Plot your data scimply

github.com/EnzoBnl/Scimple

enzobonnal@gmail.com

TEST:

Test package by running: 
`pip install scimple`

or:
`git clone https://github.com/EnzoBnl/Scimple`
and
`pip install .`

Then run the test notebook
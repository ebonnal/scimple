# Scimple package
# Author: Enzo Bonnal (enzobonnal@gmail.com)
__version__ = '1.11.0'
print('using scimple', __version__)


from .plot import *
from .utils import *
from .stats import *
from .graph import *
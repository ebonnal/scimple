Scimple Lib
Plot your data scimply
github.com/EnzoBnl/Scimple

Enzo Bonnal
enzobonnal@gmail.com
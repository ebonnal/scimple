Scimple
Plot your data in 3 lines
github.com/EnzoBnl/Scimple